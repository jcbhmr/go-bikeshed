from .stringenum import StringEnum
